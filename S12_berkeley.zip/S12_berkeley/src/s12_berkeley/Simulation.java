
package s12_berkeley;

public class Simulation
{

    public static void main(String[] args) 
    {
        SimulatorMonitor  sm = new SimulatorMonitor();
        Server srv = new Server(sm);
        srv.start();
        Client clv[] = new Client[4];
        for(int i=0;i<4;i++)
        {
          clv[i] = new Client(i, sm);
          clv[i].start();
        }
        
    }
    
}
