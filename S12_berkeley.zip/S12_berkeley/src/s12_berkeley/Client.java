
package s12_berkeley;
import java.io.*;
import java.net.*;
import java.util.*;

public class Client extends Thread
{

        private long clientTime;
        private int clientID;
        private SimulatorMonitor sm;
        private final boolean addDelay = true;
        
        public Client(int clientID,SimulatorMonitor sm)
        {
         this.sm = sm;
         this.clientID= clientID;
         this.clientTime= System.nanoTime();
        }
        
        public void run()
        {
          while(true)
          {
            this.clientTime += (this.addDelay) ? (this.clientID+1)*2: 0;
            System.out.println("Temporizacion (cliente "+ clientID +") :" + this.clientTime);
            this.sm.setDiffTimes(this.clientTime,this.clientID);
            this.clientTime += this.sm.getSettingTime(this.clientID);
            System.out.println("Temporizacion acordada (cliente " + clientID +") :" + this.clientTime);
          }
        }    
}
    

